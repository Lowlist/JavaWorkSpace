package CheckAndCash;

import MenuInfo.MainFunsion;
import MenuInfo.Product;
import Util.Cw;

public class MenuCheck {
		
	public static void drinkcheckrun() {
	
		int check_hotcoffee = 0;
		int check_icecoffee = 0;
		int check_ichigo = 0;
		int check_momo = 0;
		
		if(!MainFunsion.drink_T.isEmpty()) {
	for(int i=0;i < MainFunsion.drink_T.size();i++) {
		Product drinks_order = MainFunsion.drink_T.get(i);
		
		if(drinks_order.name.equals("뜨거운커피")) {
			check_hotcoffee++;	
		}
		
		if(drinks_order.name.equals("아이스아메리카노")) {
			check_icecoffee++;	
		}
		
		if(drinks_order.name.equals("딸기스무디")) {
			check_ichigo++;	
		}
		
		if(drinks_order.name.equals("복숭아스무디")) {
			check_momo++;	
		}
		}
		Cw.wn("============================");
		Cw.wn("뜨거운커피:[" + check_hotcoffee +"]");
		Cw.wn("아이스아메리카노:[" + check_icecoffee+"]");
		Cw.wn("딸기스무디:[" + check_ichigo+"]");
		Cw.wn("복숭아스무디:[" + check_momo+"]");
		Cw.wn("============================");
		}else {
			Cw.wn("드링크 장바구니에 아무것도 담겨있지 않습니다!");
		}
	}
	
	public static void dessertcheckrun() {
		int check_cake = 0;
		int check_macaron = 0;
		int check_sandwich = 0;
		if(!MainFunsion.dessert_T.isEmpty()) {
		for(int i=0 ;i <MainFunsion.dessert_T.size() ;i++ ) {
			Product dessert_order = MainFunsion.dessert_T.get(i);  
			
			if(dessert_order.name.equals("케이크")) {
				check_cake++;
			}
			if(dessert_order.name.equals("마카롱")) {
				check_macaron++;
			}
			if(dessert_order.name.equals("샌드위치")) {
				check_sandwich++;
			}
		}
		Cw.wn("============================");
		Cw.wn("케이크:[" + check_cake +"]");
		Cw.wn("마카롱:[" + check_macaron+"]");
		Cw.wn("샌드위치:[" + check_sandwich+"]");
		Cw.wn("============================");
		} else {
			Cw.wn("디저트 장바구니에 아무것도 담겨있지 않습니다!");
		}
	}
	
}	
	
