package MainKiosk;

import CheckAndCash.MenuCheck;
import MenuInfo.DessertData;
import MenuInfo.MainFunsion;
import MenuInfo.Product;
import Util.Cw;

public class Dessert {
	//디저트 화면 출력란
	public static void dessertinfo(){
		Cw.wn("-------디저트 메뉴입니다-------");
		for(Product de :MainFunsion.dessert) {
			if(de instanceof DessertData) {
				Cw.wn(de.number+"."+de.name+" ["+de.price +"]원");
			}
		}
		Cw.wn("------------------------");
	dessertstrat:
	while(true) {
			Cw.wn("디저트를 선택해주세요!");
			Cw.wn("메인메뉴로 돌아가기[e] 메뉴 다시보기 [r]");
			Cw.wn("장바구니 비우기[c] 디저트 장바구니 확인[v]");
			MainFunsion.cmd = MainFunsion.sc.next();
		switch(MainFunsion.cmd) {
			case "1":
				MainFunsion.dessert_T.add(MainFunsion.dessert.get(0));
				Cw.wn("[케이크]를 선택하셨습니다!");
				Cw.wn("------------------------");
				break;
			case "2":
				MainFunsion.dessert_T.add(MainFunsion.dessert.get(1));
				Cw.wn("[마카롱]을 선택하셨습니다!");
				Cw.wn("------------------------");
				break;
			case "3":
				MainFunsion.dessert_T.add(MainFunsion.dessert.get(2));
				Cw.wn("[샌드위치]를 선택하셨습니다!");
				Cw.wn("------------------------");
				break;
			case "r":
				System.out.println("-------디저트 메뉴입니다-------");
				for(Product de :MainFunsion.dessert) {
						Cw.wn(de.number+"."+de.name+" ["+de.price +"]원");
					}
				System.out.println("메인메뉴로 돌아가기[e] / 메뉴 다시보기 [r]");
				System.out.println("장바구니 비우기[c] 디저트 장바구니 확인[v]");
				System.out.println("---------------------------");
				break;
			case "e":
				break dessertstrat;
			case "c":
				MainFunsion.drink_T.clear();
				MainFunsion.dessert_T.clear();
				break;
			case "v":
				MenuCheck.dessertcheckrun();
				break;
			
			}
	
		}
	}
	
}
