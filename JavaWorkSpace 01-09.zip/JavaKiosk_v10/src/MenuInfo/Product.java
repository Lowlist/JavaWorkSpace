package MenuInfo;

public class Product  {
	//출력 및 오버로딩용 클래스
	
	public String name = "";
	public int price;
	public String number ="";
	//생성자 함수
	
	//오버로딩
	public Product(String xx,int yy,String aa){
		name = xx;
		price = yy;
		number = aa;
	}
	
	public void info() {
		System.out.println(number + ". 상품명: "+ name + " 가격: " + price +"원");
	}
		
	void addsetdrink() {
		System.out.println("["+ name +"] 가 선택되었습니다.");
	}
	
	public void showbarket() {
		System.out.println("["+ name +"]["+ price +"]");
	}
	
		
}
