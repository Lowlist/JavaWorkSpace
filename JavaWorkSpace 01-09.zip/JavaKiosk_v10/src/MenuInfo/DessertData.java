package MenuInfo;

public class DessertData extends Product  {
	
	public DessertData(String xx, int yy, String aa) {
		super(xx,yy,aa);
	}
	
	void addsetdrink() {
		System.out.println("["+ name +"] 가 선택되었습니다.");
	}

}
