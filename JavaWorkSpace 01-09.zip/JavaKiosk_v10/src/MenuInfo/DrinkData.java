package MenuInfo;

public class DrinkData extends Product {
	
	public DrinkData(String xx, int yy, String aa) {
		super(xx, yy, aa);
	}
	
	void addsetdrink() {
		System.out.println("["+ name +"] 가 선택되었습니다.");
	}

}
