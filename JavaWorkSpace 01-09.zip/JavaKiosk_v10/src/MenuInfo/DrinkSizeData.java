package MenuInfo;

public class DrinkSizeData extends Product {
	
	public DrinkSizeData(String xx, int yy, String aa) {
		super(xx, yy, aa);
	}
	
	void sizeinfo() {
		System.out.println(number + ".["+ name +"] 사이즈" +" 추가가격 [" + price +"]원");
	}
	
	void addsetsize() {
		System.out.println("["+ name +"] 사이즈가 선택되었습니다.");
	}
	
}
