package MySqlConnect;

public class DelAndEditConnect {

}
