package JavaFunsionData;

import java.util.ArrayList;

public class BoradFunsion {

	//카운트 데이터
	public static ArrayList<Product> countdata = new ArrayList<Product>();
	//통합 리스트
	public static ArrayList<Product> listdata = new ArrayList<Product>();
	//삭제 리스트
	public static ArrayList<Product> deldata = new ArrayList<Product>();
	//아이디 리스트
	public static ArrayList<Product> idcount = new ArrayList<Product>();
	public static ArrayList<Product> pwcount = new ArrayList<Product>();
	public static ArrayList<Product> idPwData = new ArrayList<Product>();
	
	
	
	

}
