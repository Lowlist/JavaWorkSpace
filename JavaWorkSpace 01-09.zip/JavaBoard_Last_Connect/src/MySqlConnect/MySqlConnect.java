package MySqlConnect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySqlConnect {
	public static Connection con = null;
	public static Statement st = null;
	public static ResultSet result = null;
	
	public static void writerun(String xx) {
		dbInit();
		dbExecuteUpdate(xx);
		System.out.println("글 등록 완료");
	}
	
	public static void readrun(String xx) {
		dbInit();
		dbreadrun(xx);
		System.out.println("글 읽기 완료");
	}
	
	public static void editrun(String xx) {
		dbInit(); // db 실행문
		dbeditrun(xx);
	}
	
	private static void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();	// Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet 객체만을 열 수있다.
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private static void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			System.out.println("데이터베이스에 업로드 된 글 갯수:"+resultCount);
		} catch (SQLException e) {
			e.printStackTrace();
//			System.out.println("SQLException: " + e.getMessage());
//			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private static void dbreadrun(String xx) {
	try {
		result = st.executeQuery(xx);
		result.next();	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
		String title = result.getString("b_title");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
		String content = result.getString("b_text");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
		System.out.println("글제목: "+title);
		System.out.println("글내용: "+content);
	} catch (SQLException e) {
		e.printStackTrace();
	}
}
	
	private static void dbeditrun(String xx) {
		try {
			int resultCount = st.executeUpdate(xx);
			System.out.println("처리된 행 수:"+resultCount);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
}