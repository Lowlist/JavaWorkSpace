package JavaBoradData;

public class MenuWriteData extends Product {

	public MenuWriteData(String aa) {
		super(aa);
	}
	
	
}
