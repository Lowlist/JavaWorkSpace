package JavaBoradData;

public class MenuDeditPostData extends MenuWriteData{ 

	public MenuDeditPostData(String aa) {
		super(aa);
	}

}
