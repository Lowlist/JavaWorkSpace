package JavaBoardMain;

import Util.Cw;

public class P_MenuDel {

	public static void menudelrun() {
		Cw.wn("메뉴");
	}
	
}
