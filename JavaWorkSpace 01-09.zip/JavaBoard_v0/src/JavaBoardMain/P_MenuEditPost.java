package JavaBoardMain;

import Util.Cw;

public class P_MenuEditPost {

	static void menueditpostrun() {
		
		Cw.wn("글수정");
		
	}
	
}
