package JavaBoardMain;

import Display.Disp;
import JavaBoradData.DataForBorad;
import Util.Cw;

public class P_MainMenu {
	
	static void mainmenurun() {
//		Disp.menuMain();
		
		startmenu:
		while(true) {
			Disp.menuMain();
			breakpoint:
			switch(DataForBorad.cmd) {
			
			case "1":
				P_MenuList.menulistrun();
				break ;
			case "2":
				P_MenuEditPost.menueditpostrun();
				break ;
			case "3":
				P_MenuWrite.menuwriterun();
				break ;
			case "4":
				P_MenuDel.menudelrun();
				break ;
			case "e":
				Cw.wn("프로그램을 종료하겠습니다.");
				break startmenu;
			default:
				Cw.wn("정해진 명령문을 입력해주세요!");
				break;
			}
			
			
		}
		
		
	}
}
