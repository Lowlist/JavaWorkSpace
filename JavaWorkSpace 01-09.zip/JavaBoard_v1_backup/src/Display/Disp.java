package Display;

import JavaBoradData.DataForBorad;
import Util.Cw;

public class Disp {
	public static void title() {
		Cw.line();
		Cw.dot();
		Cw.space(17);
		Cw.w(DataForBorad.TITLE);
		Cw.space(17);
		Cw.dot();
		Cw.wn();
		Cw.line();
	}
	public static void menuMain() {
		Cw.dot();
		Cw.space(15);
		Cw.w("[1.글리스트/2.글쓰기/3.삭제 및 수정/e.종료]");
		Cw.space(14);
		Cw.dot();
		Cw.wn();
	}

}
