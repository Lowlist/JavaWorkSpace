package JavaBoradData;

public class Product {

	public String text = "";
	public String title = "";
	public String content = "";
	public String write = "";
	public int removed = 0;
	
	// 0
	
	
	public Product (String aa){
		
		text = aa;
		
	}

	public Product(String aa ,String bb, String cc) {
		title = aa;
		content = bb;
		write = cc;
	}
	
	
	
}
