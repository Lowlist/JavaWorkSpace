package JavaBoardMain;

import java.time.LocalDate;

import JavaBoradData.BoradFunsion;
import JavaBoradData.DataForBorad;
import JavaBoradData.Product;
import Util.Cw;

public class P_MenuList {

	static void menulistrun() {
		LocalDate now = LocalDate.now();
		DataForBorad.date = now.toString();
		int list_number = 0;
		for (int i = 0; i < BoradFunsion.titledata.size(); i++) {
			Product list_all = BoradFunsion.listdata.get(i);
			list_number = i + 1;
			Cw.w("No." + list_number + " ");
			Cw.w("제목:" + list_all.title + "/");
			Cw.w("작성자:" + list_all.write + "/");
			Cw.wn("조회수:" + DataForBorad.view_limit);
			Cw.wn("작성일:" + DataForBorad.date);
			Cw.wn("〓〓〓〓〓〓〓〓〓〓〓〓〓");

		}
	}
	
}